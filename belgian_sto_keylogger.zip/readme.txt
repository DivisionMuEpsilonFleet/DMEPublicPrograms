Guide:
1. ? will reset the .log file to have zero entries. I have a keybind in STO Keybinds which has it also trigger Pm to me saying "Video Sychronzied" so I know it was recieved. This is advised to be the "Shift + ," keybind

2. PgDwn Key turns off key logger

3. Will generate a .log file in the same location as the .py script

4. This script requires administration permissions in order to pull the key activations while the focus of Windows is on STO. You may get asked to install various python libraries to achiveve this goal.
-> pip install pypiwin32 for example

5. Don't leave the script running for too long. There shouldn't be an issues in doing so, but the log file will grow very fast. A 10 minute STO PvP fight will typially generalte between 100kb - 300kb of data if there are no macros involved. 
