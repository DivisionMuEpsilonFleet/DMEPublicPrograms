Guide:

Installation:
1. Run the "Installer.bat" program and type in relevant choices in the pop-up terminal. Double LEFT click to run .bat files.

Operation:
1. Run the "run.bat" file. Double LEFT click to run .bat files.
2. PgDwn Key turns off the keylogger. 
3. The script will generate key log entries in the logs folder

Liability + Disclaimer:
I am not a 'professional', don't get mad at me if something goes wrong, use at your own risk. 

Other Notes:
1. This script requires administration permissions in order to pull the key activations while the focus of Windows is on STO. 
2. Don't leave the script running for too long. There shouldn't be an issues in doing so, but the log file will grow very fast. A 10 minute STO PvP fight will typially generalte between 100kb - 300kb of data if there are no macros involved. 


Game ToS Compliance:
1. To any dumb person who comes across this file and things its some sort of "DME Cheating" or scripting and can't be bothered to read the actual code, no it isn't. This is a method to extract game activations from our KEYBOARD + MOUSE and log them into a text file so we can compare them to a video.
This is no different than setting up a camera over our keyboards and recording our keystrokes with a video camera as we do PvP. Its just more clean and easier to do than that. This doesn't interact with the game in any way and is not a method of inputing
keystrokes into the game for us. 