import pynput
import time
import pyuac
import string
from pynput.keyboard import Listener  as KeyboardListener
from pynput.mouse    import Listener  as MouseListener
from pynput.keyboard import Key
from datetime import datetime
from sto_keylogger_interpreter import keyboard_input_interpreter_function
import INFO_keylogger_configs
import os
from termcolor import colored, cprint

print("\n\nThis Program Was Made by the Division Mu Epsilon Community, a fleet specializing in High-End PvP and DPS!")
print("/| Link to our discord server: https://discord.gg/Kp2AuMtC6c")
time.sleep(2)

TARGET_LOG_FILE = "EmptyLogFileDest"
Operating_Directory = INFO_keylogger_configs.DIRECTORY_OF_PROGRAM   #closest folder which contains all files in the program
KILLKEY = INFO_keylogger_configs.RESET_KEY_CHOICE                   #which key causes a new log to start
LANGUAGE_CONFIGS = INFO_keylogger_configs.LANG_CHOICE               #specify language / keyboard choices for non-qwerty board users
SET_LOG_ENTRY_LENGTH_LIMITER = INFO_keylogger_configs.LENGTH_CHOICE #used to format the log so that we can easily read it. This is *fixed* length all log entries will be.


global START_TIME
START_TIME = 0
global CURRENT_TIME
CURRENT_TIME = 0

SET_LOG_ENTRY_LENGTH_LIMITER = 35 #used to format the log so that we can easily read it. This is *fixed* length all log entries will be.

def update_current_time():
      global CURRENT_TIME
      CURRENT_TIME = time.time()

def update_start_time():
      global START_TIME
      START_TIME = time.time()
      update_target_log()

def update_target_log():
      global TARGET_LOG_FILE
      #formatting to remove useless values so log dates are more readable and remove useless levels of precision
      now = str(datetime.now())
      now = now[0:len(now)-5] 
      now = now.replace(":", "_") 

      # new target logfile is the operating directory of this code, in the log folder, for the most recent time we are logging
      TARGET_LOG_FILE = Operating_Directory+"\\logs\\V2_KEYLOGGER_LOGFILE_"+now+".log" #sets logfile to current directory
      print("\nNew_Log_File:" + TARGET_LOG_FILE)
      with open(TARGET_LOG_FILE, 'w') as v:
            v.write("Logging Session On: " + str(datetime.now()) +  " Local Time Zone" + "\nVideo Synchronization Marker")
            v.close()

def log_formatter(input):
      k = input     
      if((len(k) < SET_LOG_ENTRY_LENGTH_LIMITER)): #only doing this to format the k string to be set_log_entry_event_length_limiter chars long
                  for i in range(0,SET_LOG_ENTRY_LENGTH_LIMITER-len(k)): #if string is < set_log_entry_event_length_limiter long, then we will fill it up with a bunch of extra white spaces to format it for the log file. 
                        k = k+" "
      if(len(k)> SET_LOG_ENTRY_LENGTH_LIMITER):
                  k = k[0:SET_LOG_ENTRY_LENGTH_LIMITER] #ensures that very large strings will simply be trimmed to fit the desired length of a log entry
      return k 

def write_file(key): #key may not always be a 'Key' Object, it may also be a string such as in the case of the mouse listener. 
      update_current_time()
      with open(TARGET_LOG_FILE, 'a') as f: #original code had it re-write the entire file each time with a list, which seemed very in-efficient and like it would cause memory issues. I am not sure though, how this append works. If it accepts the entire .txt file into memory, the original implemention might have been superior. 
            # removing ''
            k = str(key).replace("'", "")
            k,question_new_start_time = keyboard_input_interpreter_function(k, LANGUAGE_CONFIGS, TARGET_LOG_FILE, KILLKEY)
            
            if( int(question_new_start_time) != -1): #if this isn't negative one, then its the timestamp if the log reset key is triggered
                  update_start_time()
                  #updates target log file and inputs relevant data at top of file
                  update_target_log()
                  with open(TARGET_LOG_FILE, 'a') as t:
                        k = log_formatter(k)
                        t.write("\n   " + k + " - Time: " + ("%.7f" % round(CURRENT_TIME-START_TIME, 2)) )
                        t.close()
                        #will reset log to new log and reset start time
            else:
                  k = log_formatter(k)
                  f.write("\n   " + k + " - Time: " + ("%.7f" % round(CURRENT_TIME-START_TIME, 2)) ) #only need so much data here about the time stamps, and this will be a 'greedy' source of storage for the log file
            
            
            # explicitly adding a space after 
            # every keystroke for readability
            f.write(' ') 
            f.close()

       
                         
def on_release(key):          
    #print('{0} released'.format(key))
    if key == Key.page_down:
        # Stop listener
        return False
    write_file(key)

def on_click(x, y, button, pressed):
       if pressed:
              mouse_singal_string = ""
              if(str(button) == "Button.left" or str(button) == "Button.right"):#only really care about coordinates here when left or right pressing, so this only sends over 
                    mouse_singal_string = str(button) + "@x=" + str(x) + "y=" + str(y) 
              else:
                    mouse_singal_string = button

              write_file(mouse_singal_string)
              #note, that write_file() takes a key object input, but it can still be accepted as a string, and the function automatically converts said inputs to string anyways

#Running as Admin is nessecary in many games for whatever unknown reason. Cursory research seems to indicate issues with DirectX and Windows but honestly who knows :shrugs_non-chalantly:
def main():
       #this main segment is only ran one time
       update_start_time()
       update_target_log()
       update_current_time()

       #this is a hook on the OS
       with MouseListener(on_click=on_click) as listener:
              with KeyboardListener(on_release = on_release) as listener:
                     listener.join()
    
if __name__ == "__main__":
    if not pyuac.isUserAdmin():
        print("Re-launching as admin!")
        pyuac.runAsAdmin()
    else:        
        main()  # Already an admin here.