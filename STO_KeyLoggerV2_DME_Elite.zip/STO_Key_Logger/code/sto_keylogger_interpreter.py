import time
from datetime import datetime

LIST_OF_KEYBOARD_CONFIGS = [ 'QWERTY', 'AZERTY' ]

#azerty board for dutch users
def azerty_interpreter(k, TARGET_LOG_FILE, killkey):
    data_package = ["",-1]
    #left entry is the key, and right entry is an optional entry for time on reset if that feature is used

    if(k == "1"):
           data_package[0] = "Shift + 1"

    elif(k == "2"):
           data_package[0] = "Shift + 2"
    
    elif(k == "3"):
           data_package[0] = "Shift + 3"
    
    elif(k == "4"):
           data_package[0] = "Shift + 4"
    
    elif(k == "5"):
           data_package[0] = "Shift + 5"
    
    elif(k == "6"):                                        
           data_package[0] = "Shift + 6"
    
    elif(k == "7"):                                        
           data_package[0] = "Shift + 7"
    
    elif(k == "8"):
           data_package[0] = "Shift + 8"
    
    elif(k == "9"):
           data_package[0] = "Shift + 9"
    
    elif(k == "0"):
           data_package[0] = "Shift + 0"

    elif(k == "&"):
           data_package[0] = "1"

    elif(k == "é"):
           data_package[0] = "2"
   
    elif(k == "\""):
           data_package[0] = "3"
   
    elif(k == "\"\""):
           data_package[0] = "4"
   
    elif(k == "("):
           data_package[0] = "5"
   
    elif(k == "§"):
           data_package[0] = "6"
   
    elif(k == "è"):
           data_package[0] = "7"
   
    elif(k == "!"):
           data_package[0] = "8"
  
    elif(k == "ç"):
           data_package[0] = "9"
   
    elif(k == "à"):
           data_package[0] = "0"

    elif(k == "`"): #invalid in the general case but its the same key in sto keybinds so meh
            data_package[0] = "` or ~"
    
    elif( k.isupper() ): #Just here to convert entries like "T" -> "Shift + t" for readability
            data_package[0] = ("Shift + " + k.lower())
    
    elif(k == killkey): #very specific key in my STO Keybinds file so I can do a video sychronization mark 
            start_time = time.time()
            data_package[0] = "? Video Synchronization Marker"
            data_package[1] = start_time #configs 2nd entry in the return list to be the start time, otherwise it is -1
    else:
           data_package[0] = k
    return data_package
  
#US-English QWERTY Board    
def qwerty_interpreter(k, TARGET_LOG_FILE, killkey):
    data_package = ["",-1]
    #left entry is the key, and right entry is an optional entry for time on reset if that feature is used
    if(k == "!"):
           data_package[0] = "Shift + 1"

    elif(k == "@"):
           data_package[0] = "Shift + 2"
    
    elif(k == "#"):
           data_package[0] = "Shift + 3"
    
    elif(k == "$"):
           data_package[0] = "Shift + 4"
    
    elif(k == "%"):
           data_package[0] = "Shift + 5"
    
    elif(k == "^"):                                        
           data_package[0] = "Shift + 6"
    
    elif(k == "&"):
           data_package[0] = "Shift + 7"
    
    elif(k == "*"):
           data_package[0] = "Shift + 8"
    
    elif(k == "("):
           data_package[0] = "Shift + 9"
    
    elif(k == ")"):
           data_package[0] = "Shift + 0"
    
    elif(k == "`"): #invalid in the general case but its the same key in sto keybinds so meh
            data_package[0] = "` or ~"
    
    elif( k.isupper() ): #Just here to convert entries like "T" -> "Shift + t" for readability
            data_package[0] = ("Shift + " + k.lower())
    
    elif(k == killkey): #very specific key in my STO Keybinds file so I can do a video sychronization mark 
            start_time = time.time()
            data_package[0] = "| Video Synchronization Marker"
            data_package[1] = start_time #configs 2nd entry in the return list to be the start time, otherwise it is -1
    else:
           data_package[0] = k

    return data_package     

#basically this just figures out what type of keyboard we are interpreting and then will grab the relevant equivalent in QWERTY
def keyboard_input_interpreter_function(stroke, interpretation_key, TARGET_LOG_FILE, killkey):
    if(interpretation_key == "AZERTY"):
        return azerty_interpreter(stroke, TARGET_LOG_FILE, killkey)
    elif(interpretation_key == "QWERTY"):
        return qwerty_interpreter(stroke, TARGET_LOG_FILE, killkey)
    else:
        return str(stroke) + "-   ERROR! - NO INTERPRETATION KEY"
    