import subprocess
import os
import re
import sys
import sto_keylogger_interpreter
import time

# Using system() method to
# execute shell commands
Commands = []

Commands.append("pip install termcolor") #putting in the beginning to ensure it installs first
Commands.append("pip install pynput")
Commands.append("pip install pynput")
Commands.append("pip install pyuac")
Commands.append("pip install win32security") 
Commands.append("pip install pywin32") 
Commands.append("pip install datetime")
Commands.append("pip install Key")
Commands.append("pip install Listener")
Commands.append("echo \"%cd%\" > code\\working_dir.txt")

try:
    for cmd_iterator in Commands:
        subprocess.run(["powershell", cmd_iterator], shell=True)
    from termcolor import colored, cprint # doing the import here so we can cheese the cprint input and not have to put it in the bat file
    cprint('Successfully Downloaded All Dependancies', 'white', 'on_green')
except:
    cprint('Failed to Download All Dependancies', 'white', 'on_red')
    sys.exit()
    

directory_name_result = ""
with open(str(os.getcwd())+"\\code\\working_dir.txt","r") as f:
    directory_file = f.read()
    for k in directory_file:
        extracted_string = str(k)
        if(extracted_string.isprintable()):
            directory_name_result = directory_name_result + extracted_string
    
    #only here to remove the power shell prefix the command line forces into the output
    directory_name_result = directory_name_result[2:len(directory_name_result)]
    directory_name_result = re.escape(directory_name_result)

    cprint('Successfully Located Directory Name', 'green')
    cprint('Dir Name: ' + directory_name_result, 'green')

#Checks if were using QWERTY, AZERTY, or some other keyboard type
language_specified = ''
while(language_specified not in sto_keylogger_interpreter.LIST_OF_KEYBOARD_CONFIGS):
     cprint(sto_keylogger_interpreter.LIST_OF_KEYBOARD_CONFIGS, 'cyan')
     cprint("Specify Language Choice from the Above Options:",  'cyan')
     language_specified = input()


#the key that will be used to generate a new log file
#need a bool here because we really don't care what they type in as long as it is an int and a valid int >= 1
formatting_length = 35
no_format_choice_length = True
while(formatting_length < 1 or no_format_choice_length):
     cprint("Type how many charachters you want each log entry to have Ex: 35 (Recommended is 35)", 'yellow')
     cprint("Specify Choice:",  'yellow')
     formatting_length = int(input())
     no_format_choice_length = False

killkey = '' #key to reset the keylogger
while(len(killkey) == 0 or len(killkey)>1):
     cprint("Only Type In One Charachter for this, so if you choose for example |, your typing on your board and press the keystrokes to produce the | charachter, this will reset the keylogger and new data will go to a new file", 'red')
     cprint("Type in the SINGLE Charachter you want to use to reset the keylogger:",  'red')
     killkey = input()

configs_string = ""
with open(str(os.getcwd())+"\\code\\INFO_keylogger_configs.py", 'w') as v: 
        configs_string =                   'DIRECTORY_OF_PROGRAM = \'' + directory_name_result + '\'\n'
        configs_string =  configs_string + 'LANG_CHOICE = \'' + language_specified + '\'\n'
        configs_string =  configs_string + 'LENGTH_CHOICE = \'' + str(formatting_length) + '\'\n'
        configs_string =  configs_string + 'RESET_KEY_CHOICE = \'' + killkey + '\'\n'

        cprint("\n\nYour Current Configs: \n" + configs_string, 'green')
        v.write(configs_string)
        v.close()

print("\n\n")
cprint("This Program Was Made by the Division Mu Epsilon Community, a fleet specializing in High-End PvP and DPS!", 'blue')
cprint("/| Link to our discord server: https://discord.gg/Kp2AuMtC6c", 'yellow')
time.sleep(2)
    
